#ifndef __ENGINE_H__
#define __ENGINE_H__

#include <SFML/Graphics.hpp>
#include "RichText.hpp"
#include <random>
#include <utility>
#include <vector>


class engine
{
public:

    static void run();

private:

    static sf::RenderWindow* window;
    static std::string* createChristmassTree();
    static sfe::RichText displayChristmassTree(std::string* tree);
    static sf::Texture backgroundTexture;
    static sf::Texture snowSnakeTexture;

    static sf::Sprite backgraundSprite;
    static sf::Sprite snowSnakeSprite;
    static sf::Event keybEvent;


};

#endif
