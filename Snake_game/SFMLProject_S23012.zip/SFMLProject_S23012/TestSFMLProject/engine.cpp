#include "engine.h"

//#include "engine.h"
#include <iostream>
#include <windows.h>  
using namespace std;

sf::RenderWindow* engine::window = new sf::RenderWindow(sf::VideoMode(900, 600), "Snake Christmas Animations", sf::Style::Titlebar | sf::Style::Close);
sf::Texture engine::backgroundTexture;
sf::Texture engine::snowSnakeTexture;
sf::Sprite engine::backgraundSprite;
sf::Sprite engine::snowSnakeSprite;
sf::Event engine::keybEvent;
enum Direction { UP, RIGHT, DOWN, LEFT };
enum Colors
{
    BLUE = 1,
    GREEN = 2,
    RED = 4,
    VIOLET = 5,
    YELLOW = 6,
    WHITE = 7,
    BRIGHT_BLUE = 9,
    BRIGHT_GREEN = 10,
    BRIGHT_YELLOW = 14
};

const char SYMBOL_STAR = '*';
const char SYMBOL_GRID = '#';
const char SYMBOL_SPHERE = 'O';
const char SYMBOL_DOG = '@';
const char SYMBOL_PLUS = '+';
const char SYMBOL_PERSENT = '%';
const char SYMBOL_AMPERSAND = '&';

const int zeroPosition = 0;
int heigh = 20;
int outputType = 0;
int row = 0;
int column = 0;
int length = 0;
bool flag = false;
int widthBound = 30;
int heightBound = 20;
int direction;
int lengthOfSnake = 5;
int treeCounter = 0;
int sizeOfMovigArea = 30;
struct SnowSnake
{
    int x, y;
}  snakePos[100];

struct Snowflake
{
    int x, y;
} snowflake;

bool grafFlag = true;
int width = sizeOfMovigArea * widthBound;
int height = sizeOfMovigArea * heightBound;

void Teak()
{
    for (int i = lengthOfSnake; i > 0; --i)
    {
        snakePos[i].x = snakePos[i - 1].x;
        snakePos[i].y = snakePos[i - 1].y;
    }

    switch (direction)
    {
    case 0: snakePos[0].y += 1; break;
    case 1: snakePos[0].x -= 1; break;
    case 2: snakePos[0].x += 1; break;
    case 3: snakePos[0].y -= 1; break;
    }


    if (snakePos[0].x == snowflake.x && snakePos[0].y == snowflake.y)
    {
        lengthOfSnake++;
        snowflake.x = rand() % widthBound;
        snowflake.y = rand() % heightBound;
    }

    if (snakePos[0].x > widthBound)
    {
        snakePos[0].x = zeroPosition;
    }
    if (snakePos[0].x < zeroPosition)
    {
        snakePos[0].x = widthBound;
    }
    if (snakePos[0].y > heightBound)
    {
        snakePos[0].y = zeroPosition;
    }
    if (snakePos[0].y < zeroPosition)
    {
        snakePos[0].y = heightBound;
    }

    for (int j = 1; j < lengthOfSnake; j++)
    {
        if (snakePos[0].x == snakePos[j].x && snakePos[0].y == snakePos[j].y)
            lengthOfSnake = j;
    }
}

void engine::run()
{
    srand(time(0));
    snowflake.x = 15;
    snowflake.y = 15;
    backgroundTexture.loadFromFile("white.png");
    snowSnakeTexture.loadFromFile("red.png");
    backgraundSprite.setTexture(backgroundTexture);
    snowSnakeSprite.setTexture(snowSnakeTexture);

    sf::Clock clock;
    sf::Time time1;
    float timer = 0;
    float detain = 0.2f;
    while (window->isOpen())
    {
        float currentTimeInSec = clock.getElapsedTime().asSeconds();
        clock.restart();

        timer += currentTimeInSec;        
        while (window->pollEvent(keybEvent))
        {
            if (keybEvent.type == sf::Event::Closed)
                window->close();
        }
        switch (keybEvent.type)
        {
            
        case sf::Event::KeyPressed:
            switch (keybEvent.key.code)
            {
            case sf::Keyboard::Left:
            {
                direction = 1;
            }
                break;
            
            case sf::Keyboard::Right:
                direction = 2;
                break;
            case sf::Keyboard::Up:
                direction = 3;
                break;
            case sf::Keyboard::Down:
                direction = 0;
                break;
            case sf::Keyboard::Num1:
                //Game::increasePicture();
                break;
            case sf::Keyboard::Num2:
                //Game::decreasePicture();
                break;
            }
        }

        if (timer > detain)
        {
            timer = 0; 
            Teak();
        }

        window->clear();

        for (int i = 0; i < widthBound; i++)
        {
            for (int j = 0; j < heightBound; j++)
            {
                backgraundSprite.setPosition(i * sizeOfMovigArea, j * sizeOfMovigArea);
                window->draw(backgraundSprite);
            }
        }

        for (int i = 0; i < lengthOfSnake; i++)
        {
            snowSnakeSprite.setPosition(snakePos[i].x * sizeOfMovigArea, snakePos[i].y * sizeOfMovigArea);
            window->draw(snowSnakeSprite);
        }

        snowSnakeSprite.setPosition(snowflake.x * sizeOfMovigArea, snowflake.y * sizeOfMovigArea); 
        window->draw(snowSnakeSprite);
        
        std::string* tree = createChristmassTree();
        // Display the Christmass tree
        sfe::RichText text = displayChristmassTree(tree);
        window->draw(text);
        window->display();   

    }
}


string* ::engine::createChristmassTree()
{
    string* arr = new string[heigh];

    for (row = 0; row < heigh - 3; row++)
    {
        string wadding(heigh - row + 1, '-');
        string branch(1 + row * 2, SYMBOL_GRID);
        arr[row] = wadding + branch;
    }

    for (row = 0; row < heigh; row++)
    {
        length = arr[row].length();
        for (column = heigh - row + 1; column < length; column++)
        {
            if (rand() % 6 == 0)
                arr[row].at(column) = SYMBOL_SPHERE;
        }
    }

    for (row = 0; row < heigh; row++)
    {
        length = arr[row].length();
        for (column = heigh - row + 1; column < length; column++)
        {
            if (rand() % 8 == 0)
                arr[row].at(column) = SYMBOL_AMPERSAND;
        }
    }

    for (row = 0; row < heigh; row++)
    {
        length = arr[row].length();
        for (column = heigh - row + 1; column < length; column++)
        {
            if (rand() % 10 == 0)
                arr[row].at(column) = flag ? SYMBOL_PLUS : SYMBOL_DOG;
        }
    }

    for (row = heigh - 3; row < heigh; row++)
    {
        string wadding(heigh - 1, ' ');
        string trunk(5, SYMBOL_PERSENT);
        arr[row] = wadding + trunk;
    }
    arr[0][heigh + 1] = SYMBOL_STAR;


    return arr;
}
sf::Font font;
//sf::Text text;

sfe::RichText engine::displayChristmassTree(std::string* tree)
{
    sfe::RichText text;
    font.loadFromFile("times.ttf");
    text.setFont(font);
    char currentSymbol;
    std::string str;
    text << sf::Text::Regular << sf::Color::Green << "\n";
    for (row = 0; row < heigh; row++)
    {
        length = tree[row].length();
        //text << sf::Text::Regular << sf::Color::Green << tree[row];
        for (column = 0; column < length; column++)
        {
            currentSymbol = tree[row].at(column);
            text << sf::Text::Regular << sf::Color::Green << currentSymbol;
            str += currentSymbol;
            //Paint symbols by different colours
            switch (currentSymbol)
            {
            case SYMBOL_STAR:
                text << sf::Text::Regular << sf::Color::Yellow << currentSymbol;
                break;

            case SYMBOL_GRID:
                text << sf::Text::Regular << sf::Color::Green << currentSymbol;
                break;

            case SYMBOL_PERSENT:
                text << sf::Text::Regular << sf::Color::Blue << currentSymbol;                
                break;

            case SYMBOL_AMPERSAND:
                text << sf::Text::Regular << sf::Color::Yellow << currentSymbol;
                break;

            case SYMBOL_PLUS:
                text << sf::Text::Regular << sf::Color::Yellow << currentSymbol;                
                break;

            case SYMBOL_DOG:
                text << sf::Text::Regular << sf::Color::Red << currentSymbol;                
                break;

            case SYMBOL_SPHERE:
                text << sf::Text::Regular << (flag ? sf::Color::Black : sf::Color::Red) << currentSymbol;
                //SetConsoleTextAttribute(hConsole, flag ? BLUE : RED);
                break;
            }
            // Display symbol
            //text.setString("TEST  hakjdnfkdasjnaskna\nsdnasdmnlasn");
            ////// set the character size
            //text.setCharacterSize(24); // in pixels, not points!

            ////// set the color
            //text.setFillColor(sf::Color::Red);

            ////// set the text style
            //text.setStyle(sf::Text::Bold | sf::Text::Underlined);
            //text.setPosition(0,0);
            //window->draw(text);
            //writeTo(currentSymbol);
        }
        text << "\n";
        str += "\n";
        //writeTo('\n');
        flag = !flag;
    }
    //text.setString(str);
    //// set the chracter size
    text.setCharacterSize(20); 

    //// set the color
    //text.setFillColor(sf::Color::Green);

    //// set the text style
    //text.setStyle(sf::Text::Bold);
    text.setPosition(100, 0);
    //window->draw(text);
    return text;
}

